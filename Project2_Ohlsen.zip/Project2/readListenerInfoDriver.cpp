#include "Listener.h"
#include <fstream>
#include <iostream>

using namespace std;


/* 
This function takes a string and splits into pieces based on a seperator and stores the pieces in an array of a user-given size
Parameters: string myStr (the string being split), char seperator, string arr[] (where pieces are stored), int arr_size (cannot get size of arr[] without input)
Return: int num_pieces (number of pieces the string was split into)
*/
int split(string myStr, char seperator, string arr[], int arr_size){

    int previous_index = 0;
    int counter = 0;
    int num_pieces = 0;

    

    for(int i = 0; i < myStr.length(); i++){

        if(num_pieces + 1 > arr_size){
            return -1;
        }

        string temp;

        if(i == myStr.length() - 1){

            // if at end of string, take last string (no comma at the end)
            temp = myStr.substr(previous_index, i - previous_index + 1);
            arr[counter] = temp;
            num_pieces++;
            
            

        }else if(myStr[i] == seperator){

            if(previous_index == 0){
                // first substr
                temp = myStr.substr(previous_index, i - previous_index);
                previous_index = i + 1;
                arr[counter] = temp;
                counter++;
                num_pieces++;

            }else{
                // middle substr's sandwiched by commas
                temp = myStr.substr(previous_index , i - previous_index);
                previous_index = i + 1;
                arr[counter] = temp;
                counter++;
                num_pieces++;
            }
            
        }


    }



    return num_pieces;
}

/*
This function takes in a file of listeners and stored it into the listeners array up until it reaches its max size, then returns number of listeners stored in array post-function
Parameters- string fileName, listeners[] (array of Listener objects), int numListenersStored (current # of listeners in array), int listenerArrSize (size of listeners[]), int maxCol (should be 51)
Return- int numListeners (number of listeners stored in listeners[] after function is performed OR error #)
*/
int readListenerInfo(string fileName, Listener listeners[], int numListenersStored, int listenerArrSize, int maxCol=51){

    // input validation for numListenersStored, listenerArrSize, and maxCol
    if(numListenersStored < 0 || listenerArrSize < 0 || maxCol < 0){
        return 0; 
    }

    // if number of listeners stored is greater than listenerArrSize, then return -2
    if(numListenersStored >= listenerArrSize){
        return -2;
    }
    
    
    int numListeners = numListenersStored;

    ifstream input;

    input.open(fileName);

    // if able to open file, continue program
    if(input.is_open()){

        

        input.seekg(0, ios::end);
        unsigned long long last_pos = input.tellg();

        

        // if last position is zero, the file is empty
        if(last_pos != 0){

            // file is not empty

            // set cursor back to beginning of file
            input.seekg(0, ios::beg);

            string line;

            // while there's still a line in file and numListeners hasn't reached listenerArrSize, add listener to listeners array
            while(getline(input,line) && numListeners < listenerArrSize){

                // if line is empty, move on to next line
                if(line == ""){
                    continue;
                }

                // split line and store in temp array
                string temp[maxCol];
                int numColumns = split(line, ',', temp, maxCol);

                // set listener name to first element of temp 
                listeners[numListeners].setListenerName(temp[0]);

                // iterate through rest of temp[] to set fill playCount[] for listener
                for(int i = 1; i < numColumns; i++){
                    int currentPlayCount = stoi(temp[i]);
                    listeners[numListeners].setPlayCountAt((i - 1),currentPlayCount);
                }
                // the play counts after numColumns should be zero b/c Listener() sets all play counts to zero


                numListeners++;

            }


        }else{
            // file is empty
            return 0;
        }


    }else{
        // file unable to be opened
        return -1;
    }


    return numListeners;


}


int main(){

    string fileName = "listeners.txt";
    Listener listeners[100];
    int numListenersStored = 0;
    int listenerArrSize = 100;
    int maxCol = 51;

    // TEST CASE 1 - call function w/ no numListenersStored

    numListenersStored = readListenerInfo(fileName, listeners, numListenersStored, listenerArrSize, maxCol);

    cout << numListenersStored << endl; // expect 50

    // print first 10 listeners
    for (int i = 0; i < 10; i++)
    {
        cout << listeners[i].getListenerName() << " "  << listeners[i].getPlayCountAt(i) << endl;
    }





    // TEST CASE 2 - call function with some listeners already stored and array meets capacity
    Listener listenersTwo[50];
    int listenersTwoSize = 50;
    listenersTwo[0].setListenerName("Grace");
    int listenerCount = 1;

    numListenersStored = readListenerInfo(fileName, listenersTwo, listenerCount, listenersTwoSize, maxCol);

    cout << numListenersStored << endl; // expect 50

    // print first 10 listeners
    for (int i = 0; i < 10; i++)
    {
        cout << listenersTwo[i].getListenerName() << " "  << listenersTwo[i].getPlayCountAt(i) << endl;
    }




    // TEST CASE 3 - file doesn't exist
    cout << readListenerInfo("doesnt_extist.txt", listenersTwo, listenerCount, listenersTwoSize, maxCol) << endl;


    // TEST CASE 4 - array already full
    cout << readListenerInfo(fileName, listeners, numListenersStored, listenersTwoSize, maxCol) << endl; // expect -2





    



    return 0;

}