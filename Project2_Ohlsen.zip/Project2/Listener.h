#ifndef LISTENER
#define LISTENER

#include <iostream>

using namespace std;

class Listener{

    public:

        Listener();

        Listener(string name, int playArray[], int playArraySize);

        string getListenerName();

        void setListenerName(string name);

        int getPlayCountAt(int index);

        bool setPlayCountAt(int index, int value);

        int totalPlayCount();

        int getNumUniqueSongs();

        int getSize();


    private:
        string listenerName;
        static const int SIZE = 50;
        int playCount[SIZE];


};


#endif