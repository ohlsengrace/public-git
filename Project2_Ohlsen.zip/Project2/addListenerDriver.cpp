#include "Listener.h"
#include <fstream>
#include <iostream>

using namespace std;


/* 
This function takes a string and splits into pieces based on a seperator and stores the pieces in an array of a user-given size
Parameters: string myStr (the string being split), char seperator, string arr[] (where pieces are stored), int arr_size (cannot get size of arr[] without input)
Return: int num_pieces (number of pieces the string was split into)
*/
int split(string myStr, char seperator, string arr[], int arr_size){

    int previous_index = 0;
    int counter = 0;
    int num_pieces = 0;

    

    for(int i = 0; i < myStr.length(); i++){

        if(num_pieces + 1 > arr_size){
            return -1;
        }

        string temp;

        if(i == myStr.length() - 1){

            // if at end of string, take last string (no comma at the end)
            temp = myStr.substr(previous_index, i - previous_index + 1);
            arr[counter] = temp;
            num_pieces++;
            
            

        }else if(myStr[i] == seperator){

            if(previous_index == 0){
                // first substr
                temp = myStr.substr(previous_index, i - previous_index);
                previous_index = i + 1;
                arr[counter] = temp;
                counter++;
                num_pieces++;

            }else{
                // middle substr's sandwiched by commas
                temp = myStr.substr(previous_index , i - previous_index);
                previous_index = i + 1;
                arr[counter] = temp;
                counter++;
                num_pieces++;
            }
            
        }


    }



    return num_pieces;
}

int readListenerInfo(string fileName, Listener listeners[], int numListenerStored, int listenerArrSize, int maxCol){

    int numListeners = numListenerStored;


    if(numListenerStored >= listenerArrSize){
        return -2;
    }

    ifstream input;

    input.open(fileName);

    if(input.is_open()){

        string line;
        string temp[maxCol];
        getline(input,line);

        if(line == ""){
            return 0;
        }else{

            
            int numColumns = split(line, ',', temp, maxCol);

            // fill name from temp
            string name = temp[0];
            

            // fill listenerCounts from temp
            int listenerCounts[maxCol - 1];

            if(numColumns >= maxCol){
                for(int i = 0; i < maxCol - 1; i++){
                    listenerCounts[i] = stoi(temp[i + 1]);
                }
            }else{
                for(int i = 0; i < numColumns; i++){
                    listenerCounts[i] = stoi(temp[i + 1]);
                }
                for(int i = numColumns; i < maxCol - 1; i++){
                    listenerCounts[i] = 0;
                }
            }

            listeners[numListeners] = Listener(name, listenerCounts, (maxCol - 1));
            numListeners++;


        }
        
        while(getline(input, line)){

            int numColumns = split(line, ',', temp, maxCol);

            // fill name from temp
            string name = temp[0];
            

            // fill listenerCounts from temp
            int listenerCounts[maxCol - 1];

            if(numColumns >= maxCol){
                for(int i = 0; i < maxCol - 1; i++){
                    listenerCounts[i] = stoi(temp[i + 1]);
                }
            }else{
                for(int i = 0; i < numColumns; i++){
                    listenerCounts[i] = stoi(temp[i + 1]);
                }
                for(int i = numColumns; i < maxCol - 1; i++){
                    listenerCounts[i] = 0;
                }
            }

            listeners[numListeners] = Listener(name, listenerCounts, (maxCol - 1));
            numListeners++;



        }

    }else{
        return -1;
    }


    return numListeners;


}

/*
This function takes in a string and returns it in its uppercase form
Parameters - string input (string w/ possible lowercase letters)
*/
string toUpper(string input){
    int length = input.length();
    for (int i = 0; i < length; i++){
        
        if(input.at(i) >= 97 && input.at(i) <= 122){
            input.at(i) = (char)(input.at(i) - 32);
        }

    }
    return input;
}




/*
This function adds new listener to listeners array
Parameters- string listenerName (name of new listener), listeners[] (array of Listener objects), int numSongs, int numListenersStored, int listenersArrSize
Return- int numListenerStored (number of listeners stored in listeners[] after function is executed OR error #)
*/
int addListener(string listenerName, Listener listeners[],int numSongs,int numListenersStored, int listenersArrSize){

    // input validation for numListenersStored and numSongs
    if(numListenersStored < 0 || numSongs < 0){
        return 0;
    }

    // numListenersStored is greater than listenersArrSize
    if(numListenersStored >= listenersArrSize){
        return -1;
    }

    // listenerName is empty
    if(listenerName == ""){
        return -3;
    }

    // check if name is already in array
    string comparisonName = toUpper(listenerName);
    

    // iterate through listeners[] to check if listener is already in array
    for(int i = 0; i < numListenersStored; i++){
        string currentName = toUpper(listeners[i].getListenerName());
        
        
        if(currentName == comparisonName){
            
            return -2;
        }
    }

    // add listener to listeners[]
    listeners[numListenersStored].setListenerName(listenerName);
    numListenersStored++;

    return numListenersStored;

}



int main(){
    
    string fileName = "listeners.txt";
    Listener listeners[100];
    int numListenersStored = 0;
    int listenerArrSize = 100;
    int maxCol = 51;

    numListenersStored = readListenerInfo(fileName, listeners, numListenersStored, listenerArrSize, maxCol);

    // TEST CASE 1 - listener already in array
    cout << addListener("Andrew",listeners, 50, numListenersStored, listenerArrSize) << endl; // expect -2

    // TEST CASE 2 - add new listener
    cout << addListener("Grace",listeners, 50, numListenersStored, listenerArrSize) << endl; // expect 51
    
    // TEST CASE 3 - array already full
    cout << addListener("Mattie",listeners, 50, 51, 51) << endl; // expect -1

    // TEST CASE 4 - empty name
    cout << addListener("",listeners, 50, 50, 51) << endl; // expect -3

    return 0;
}