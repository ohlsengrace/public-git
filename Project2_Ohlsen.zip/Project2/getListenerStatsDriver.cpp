#include "Listener.h"
#include <iomanip>

using namespace std;

/*
This function takes in a string and returns it in its uppercase form
Parameters - string input (string w/ possible lowercase letters)
*/
string toUpper(string input){
    int length = input.length();
    for (int i = 0; i < length; i++){
        
        if(input.at(i) >= 97 && input.at(i) <= 122){
            input.at(i) = (char)(input.at(i) - 32);
        }

    }
    return input;
}

/*
This function gets the number of unique songs and the average number of listens of a given listener
Parameters- string listenerName, listeners[] (array of Listener objects), int numListenersStored (Listeners stored in listeners), int numSongs (Songs stored in songs)
Return- integer based on success or error of function... returns 1 if the function performed as expected
*/
int getListenerStats(string listenerName, Listener listeners[], int numListenersStored, int numSongs){

    // uppercase listenerName for comparison purposes
    string name = toUpper(listenerName);

    // assume listener is not in listeners array
    bool listenerFound = false;
    int listenerIndex;

    // iterate through listeners[] to see if any Listeners have name as listenerName
    for(int i = 0; i < numListenersStored; i++){
        string currentListener = toUpper(listeners[i].getListenerName());
        if(currentListener == name){
            listenerFound = true;
            listenerIndex = i; // save index of listener
            break;
        }
    }

    // if listener is found, get listener stats
    if(listenerFound){

        Listener listener = listeners[listenerIndex];
        int totalPlayCount = listener.totalPlayCount();

        
        if(totalPlayCount == 0){
            // listener hasn't listened to any songs
            cout << listenerName << " has not listened to any songs."<< endl;
            return 0;
        }else{

            // listener has listened to some songs
            cout << listenerName << " listened to " << listener.getNumUniqueSongs() << " songs." << endl;
            double averageListens = (double)totalPlayCount / (double)listener.getNumUniqueSongs();
            cout << listenerName << "'s average number of listens was " << setprecision(2) << fixed << averageListens << endl;

            return 1;
        }
    }else{
        // name does not match any of the Listener's listenerName
        cout << listenerName << " does not exist." << endl;
        return -3;
    }



}






int main(){

    //Creating 3 listeners 
    Listener listeners[3];

    //Setting listenerName and num listens for Listener1 
    listeners[0].setListenerName("Listener1"); 
    listeners[0].setPlayCountAt(0,1); 
    listeners[0].setPlayCountAt(1,4); 
    listeners[0].setPlayCountAt(2,2);

    //Setting listenerName and num listens for Listener2 
    listeners[1].setListenerName("Listener2"); 
    listeners[1].setPlayCountAt(0,0); 
    listeners[1].setPlayCountAt(1,5); 
    listeners[1].setPlayCountAt(2,3);

    //Setting listenerName and num listens for Listener3 
    listeners[2].setListenerName("Listener3"); 
    listeners[2].setPlayCountAt(0,0); 
    listeners[2].setPlayCountAt(1,0); 
    listeners[2].setPlayCountAt(2,0);


    getListenerStats("Listener2", listeners, 3, 3);

    getListenerStats("Listener3", listeners, 3, 3);

    getListenerStats("Listener4", listeners, 3, 3);


    return 0;
}