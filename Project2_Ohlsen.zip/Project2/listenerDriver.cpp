#include "Listener.h"


using namespace std;

int main(){

    string nameOne = "Suzie Tunes";
    int countsOne[10] = {1,0,4,5,4,4,4,4,4,0};
    int countsOneSize = 10;

    Listener listenerOne = Listener(nameOne, countsOne, countsOneSize);

    // TEST GETTERS AND SETTERS

    // Expect Suzie Tunes, 5, and 50
    cout << listenerOne.getListenerName() << "'s play count at 3 is " << listenerOne.getPlayCountAt(3) << " and the size of her playCount array is " << listenerOne.getSize() << endl;

    listenerOne.setListenerName("Jayson Tatum");
    listenerOne.setPlayCountAt(3,4);


    // TEST PLAYCOUNTAT FOR INDEX OUTSIDE ARRAY

    cout << listenerOne.getPlayCountAt(51) << endl; // expect -1

    // Expect Jayson Tatum, 4, and 50
    cout << listenerOne.getListenerName() << "'s play count at 3 is " << listenerOne.getPlayCountAt(3) << " and the size of her playCount array is " << listenerOne.getSize() << endl;


    // TEST MEMBER FUNCTIONS

    cout << listenerOne.getListenerName() << "'s total play count is " << listenerOne.totalPlayCount() << endl; // expect 29
    cout << listenerOne.getListenerName() << "'s numUniqueSongs is " << listenerOne.getNumUniqueSongs() << endl; // expect 8


}