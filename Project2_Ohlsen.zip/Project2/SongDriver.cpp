// CSCI 1300 Fall 2021
// Author: Grace Ohlsen
// Recitation: 316 - Teo Price-Broncucia
// Homework 7 - Problem 2

#include "Song.h"

using namespace std;

int main(){


    // Check Constructor w/ no arguments + getters for title, artist, and genre
    Song s1;
    cout << "Title: " << s1.getTitle() << " by " << s1.getArtist() << ", Genre: " << s1.getGenre() << endl;

    // Check Constructor w/ arguments + getter for title, artist, and genre
    Song s2("Sorry", "Buckcherry", "Rock");
    cout << "Title: " << s2.getTitle() << " by " << s2.getArtist() << ", Genre: " << s2.getGenre() << endl;

    // Check setters for title, artist, and genre
    s1.setTitle("Pressure");
    s1.setArtist("Ari Lennox");
    s1.setGenre("R&B");
    cout << "Title: " << s1.getTitle() << " by " << s1.getArtist() << ", Genre: " << s1.getGenre() << endl;


    return 0;
}