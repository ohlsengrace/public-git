// CSCI 1300 Fall 2021
// Author: Grace Ohlsen
// Recitation: 316 - Teo Price-Broncucia
// Homework 7 - Problem 2

#include "Song.h"

using namespace std;

/*
This function prints all the Song objects in a Song array
Parameters: Song arr[] (array of Song objects), int numSongs (number of Song objects stored in Song arr[])
Return: void (no return value)... it just prints to terminal
*/
void printAllSongs(Song arr[], int numSongs){

    if(numSongs <= 0){ // no songs in arr
        cout << "No songs are stored" << endl;
    }else{
        cout << "Here is a list of songs" << endl;
        // print all songs in arr that are not empty
        for(int i = 0; i < numSongs; i++){
            string title = arr[i].getTitle();
            string artist = arr[i].getArtist();

            cout << title << " is by " << artist << endl;
        }
    }
}

int main(){

    Song songs[3] = {};
    songs[0] = Song("Hollaback Girl", "Gwen Stefani", "Pop");
    songs[1] = Song("Missed Calls", "Earthgang", "Rap");
    songs[2] = Song("Fast Car", "Tracy Chapman", "Folk");

    Song arr[0] = {};

    // TEST CASE 1 - numSongs = 0

    printAllSongs(arr, 0); // expected: No songs are stored

    // TEST CASE 2 

    printAllSongs(songs, 3); // expected: print 3 songs

    return 0;
}

