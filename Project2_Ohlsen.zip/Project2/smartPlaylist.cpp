#include "Listener.h"
#include "Song.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;


/*
This function takes in a string and returns it in its uppercase form
Parameters - string input (string w/ possible lowercase letters)
*/
string toUpper(string input){
    int length = input.length();
    for (int i = 0; i < length; i++){
        
        if(input.at(i) >= 97 && input.at(i) <= 122){
            input.at(i) = (char)(input.at(i) - 32);
        }

    }
    return input;
}

/* 
This function takes a string and splits into pieces based on a seperator and stores the pieces in an array of a user-given size
Parameters: string myStr (the string being split), char seperator, string arr[] (where pieces are stored), int arr_size (cannot get size of arr[] without input)
Return: int num_pieces (number of pieces the string was split into)
*/
int split(string myStr, char seperator, string arr[], int arr_size){

    int previous_index = 0;
    int counter = 0;
    int num_pieces = 0;

    

    for(int i = 0; i < myStr.length(); i++){

        if(num_pieces + 1 > arr_size){
            return -1;
        }

        string temp;

        if(i == myStr.length() - 1){

            // if at end of string, take last string (no comma at the end)
            temp = myStr.substr(previous_index, i - previous_index + 1);
            arr[counter] = temp;
            num_pieces++;
            
            

        }else if(myStr[i] == seperator){

            if(previous_index == 0){
                // first substr
                temp = myStr.substr(previous_index, i - previous_index);
                previous_index = i + 1;
                arr[counter] = temp;
                counter++;
                num_pieces++;

            }else{
                // middle substr's sandwiched by commas
                temp = myStr.substr(previous_index , i - previous_index);
                previous_index = i + 1;
                arr[counter] = temp;
                counter++;
                num_pieces++;
            }
            
        }


    }



    return num_pieces;
}

/*
This function reads .txt file of songs and stores Song objects in array with size songArrSize
Parameters: string fileName (name of .txt file), Song arr[] (array of Song objects), int numSongsStored (Song objects already in the array), int songArrSize (size of array)
Return: int counter (total number of Song objects stored in Song arr[])
*/
int readSongs(string fileName, Song arr[], int numSongsStored, int songArrSize){

    // if numSongsStored = size of song arrary, return -2
    if(numSongsStored == songArrSize){
        return -2;
    }



    ifstream input;
    input.open(fileName);

    if(input.is_open() ){

        string line;
        int counter = numSongsStored;

        while(getline(input,line) && counter != songArrSize){ // run loop while there are still lines and the array hasn't reached max capacity

            // temporary array for title, artist, and genre
            string temp[3];

            // if line isn't empty, split line and store as Song in array
            if(line != ""){

                split(line,',', temp,3);

                arr[counter].setTitle(temp[0]);
                arr[counter].setArtist(temp[1]);
                arr[counter].setGenre(temp[2]);

                counter++;

            }


        }


        return counter;

    }else{
        return -1;
    }

    


}


/*
This function takes in a file of listeners and stored it into the listeners array up until it reaches its max size, then returns number of listeners stored in array post-function
Parameters- string fileName, listeners[] (array of Listener objects), int numListenersStored (current # of listeners in array), int listenerArrSize (size of listeners[]), int maxCol (should be 51)
Return- int numListeners (number of listeners stored in listeners[] after function is performed OR error #)
*/
int readListenerInfo(string fileName, Listener listeners[], int numListenersStored, int listenerArrSize, int maxCol=51){

    // input validation for numListenersStored, listenerArrSize, and maxCol
    if(numListenersStored < 0 || listenerArrSize < 0 || maxCol < 0){
        return 0; 
    }

    // if number of listeners stored is greater than listenerArrSize, then return -2
    if(numListenersStored >= listenerArrSize){
        return -2;
    }
    
    
    int numListeners = numListenersStored;

    ifstream input;

    input.open(fileName);

    // if able to open file, continue program
    if(input.is_open()){

        

        input.seekg(0, ios::end);
        unsigned long long last_pos = input.tellg();

        

        // if last position is zero, the file is empty
        if(last_pos != 0){

            // file is not empty

            // set cursor back to beginning of file
            input.seekg(0, ios::beg);

            string line;

            // while there's still a line in file and numListeners hasn't reached listenerArrSize, add listener to listeners array
            while(getline(input,line) && numListeners < listenerArrSize){

                // if line is empty, move on to next line
                if(line == ""){
                    continue;
                }

                // split line and store in temp array
                string temp[maxCol];
                int numColumns = split(line, ',', temp, maxCol);

                // set listener name to first element of temp 
                listeners[numListeners].setListenerName(temp[0]);

                // iterate through rest of temp[] to set fill playCount[] for listener
                for(int i = 1; i < numColumns; i++){
                    int currentPlayCount = stoi(temp[i]);
                    listeners[numListeners].setPlayCountAt((i - 1),currentPlayCount);
                }
                // the play counts after numColumns should be zero b/c Listener() sets all play counts to zero


                numListeners++;

            }


        }else{
            // file is empty
            return 0;
        }


    }else{
        // file unable to be opened
        return -1;
    }


    return numListeners;


}


/*
This function takes in two Listener objects and the number of songs that each have listened to and returns their similarity score based on dot product
Parameters- Listener listener, Listener otherListener, int numSongs (number of songs that each Listener has listened to to be compared)
Return- int similarityScore (the dot product of the play counts of each Song)
*/
int getSimilarityScore(Listener listener, Listener otherListener, int numSongs){
    int similarityScore = 0;

    // add the product of listener's play count of song to otherListener's play count of song to similarityScore
    for(int i = 0; i < numSongs; i++){
        similarityScore += (listener.getPlayCountAt(i) * otherListener.getPlayCountAt(i));
    }

    return similarityScore;
}


/*
This function creates a playlist of songs a listener might enjoy, based on the history of another listener who has listened to similar songs
Parameters - string listenerName, string recommendedGenre, listenerArr (array of Listener objects), songsArr (array of Song objects), int numListenersStored, int numSongsStored
Return- void (just prints playlist to screen)
*/
void smartPlaylist(string listenerName, string recommendedGenre, Listener listenersArr[],Song songsArr[], int numListenersStored, int numSongsStored){

    // uppercase name and genre for comparison purposes
    string name = toUpper(listenerName);
    string genre = toUpper(recommendedGenre);

    // search to see if there's a Listener in listenersArr with the name of listenerName
    bool listenerFound = false;
    int listenerIndex;
    for(int i = 0; i < numListenersStored; i++){
        string currentListener = toUpper(listenersArr[i].getListenerName());
        if(currentListener == name){
            listenerFound = true;
            listenerIndex = i;
            break;
        }
    }

    // if the listener is found, get the listener's recommendations
    if(listenerFound){

        Listener listener = listenersArr[listenerIndex];
        int highestSimilarityScore = 0;
        int matchIndex = -1; // assume there are no matches


        // go through listeners to find listener with highest similarity score
        for(int i = 0; i < numListenersStored; i++){
        
            
            if(i == listenerIndex){ // if the listener you're looking at is the listener you're trying to compare to, move on
                continue;
            }else{
                
                Listener otherListener = listenersArr[i];

                int similarityScore = getSimilarityScore(listener, otherListener, numSongsStored) ; // get similarity score of given listener

                // if the similarity score is greater than current highest socre, update highest score and update index of listener with highest score
                if(similarityScore >= highestSimilarityScore){
                    highestSimilarityScore = similarityScore;
                    matchIndex = i;
                }
            }
        }

        // get recommendations based on listener with highest similarity score
        if(matchIndex == -1){ 
            // if no macthes, print no recommendations
            cout << "There are no recommendations for " << listenerName << " at present." << endl;
        }else{

            int numRecommendedSongs = 0;
            int counter = 0;

            int recommendedSongs[5];

            // while you haven't surpassed max recommended songs and you haven't cycled through all the songs yet, check for recommended songs
            while(numRecommendedSongs < 5 && counter < numSongsStored){

                // the listener you are looking at is the listener at the match index in listenersArr
                Listener matchedListener = listenersArr[matchIndex];

                // if the matched listener has listened to a song the listener has listened to and the genre matches input genre, store index of song into recommended songs array
                if(matchedListener.getPlayCountAt(counter) > 0 && listener.getPlayCountAt(counter) == 0 && toUpper(songsArr[counter].getGenre()) == genre){
                    recommendedSongs[numRecommendedSongs] = counter;
                    numRecommendedSongs++; // signify that one more recommended song was added
                }
                counter++;
            }



            // print recommended playlist, if applicable
            if(numRecommendedSongs == 0){
                // no recommended songs
                cout << "There are no recommendations for " << listenerName << " at present." << endl;
            }else{
                // print recommended songs (indexes are stored in recommendedSongs[])
                cout << "Here is the playlist:" << endl;
                for(int i = 0; i < numRecommendedSongs; i++){
                    cout << "Title: " << songsArr[recommendedSongs[i]].getTitle() << ", Artist: " << songsArr[recommendedSongs[i]].getArtist() << endl;
                }

            }

        }

    }else{
        // listener was not found in listenerArr
        cout << listenerName << " does not exist." << endl;
    }

    
}


int main(){


    //Creating arrays
    Song songs[50];
    Listener listeners[100];
    int numSongsStored = 0;
    int numListenersStored = 3;

    //Setting song information for song array 
    numSongsStored = readSongs("songsFile.txt", songs, 0, 50);

    //Setting listenerName and num listens for listeners array
    int arrOne[4]  = {5,1,5,3};
    int arrTwo[4]  = {5,0,3,0};
    int arrThree[4]  = {4,1,0,5};

    listeners[0] = Listener("Liz", arrOne, 4);
    listeners[1] = Listener("John",arrTwo, 4);
    listeners[2] = Listener("David",arrThree, 4);

    //Function test cases

    smartPlaylist("John", "Rock", listeners, songs, numListenersStored, numSongsStored); // expect 2 songs

    smartPlaylist("John", "rock", listeners, songs, numListenersStored, numSongsStored); // expect 2 songs

    smartPlaylist("john", "rock", listeners, songs, numListenersStored, numSongsStored); // expect 2 songs

    smartPlaylist("John", "Opera", listeners, songs, numListenersStored, numSongsStored); // expect no recommendations

    smartPlaylist("Grace", "Rock", listeners, songs, numListenersStored, numSongsStored); // expect listener not found

    

    

    return 0;
}