// CSCI 1300 Fall 2021
// Author: Grace Ohlsen
// Recitation: 316 - Teo Price-Broncucia
// Homework 7 - Problem 2

#ifndef SONG
#define SONG

#include <iostream>

using namespace std;

class Song{

    public:

    Song();

    Song(string song_title, string song_artist, string song_genre);

    string getTitle();

    void setTitle(string song_title);

    string getArtist();

    void setArtist(string song_artist);

    string getGenre();

    void setGenre(string song_genre);




    private:
        string title;
        string artist;
        string genre;



};

#endif 