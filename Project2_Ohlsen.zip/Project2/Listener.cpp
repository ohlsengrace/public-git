#include "Listener.h"


using namespace std;

// Default constructor sets listenerName to empty string and sets all elements in playCount[] to 0
Listener::Listener(){

    listenerName = "";
    for(int i = 0; i < SIZE; i++){
        playCount[i] = 0;
    }

};

/* Parameterized constructor sets listenerName to name and sets up to 50(SIZE) elements as what's stored in playArray[]
   If playArraySize is less than 50, then the rest of the elements are set to zero */
Listener::Listener(string name, int playArray[], int playArraySize){

    listenerName = name;

    // set all elemnts in playCount[] to zero
    for(int i = 0; i < SIZE; i++){
        playCount[i] = 0;
    }

    // if playArray's size is greater than or equal to SIZE, then only fill playCount[] to SIZE
    if(playArraySize >= SIZE){
        for(int i = 0; i < SIZE; i++){
            playCount[i] = playArray[i];
        }
    }else{ // if playArray's size is less than SIZE, fill playCount[] up to playArraySize... leaving the rest of the array as zero's
        for(int i = 0; i < playArraySize; i++){
            playCount[i] = playArray[i];
        }
    }

};

// returns listenerName of Listener
string Listener::getListenerName(){
    return listenerName;
};

// sets listenerName of Listener to name
void Listener::setListenerName(string name){
    listenerName = name;
};

// returns the play count of the Listener at the given index (int)
int Listener::getPlayCountAt(int index){

    if(index >= 0 && index < SIZE){
        return playCount[index];
    }else{
        return -1;
    }
    
};

// sets the play count of the Listener to value (int) at the given index (int) and return bool true if completed
bool Listener::setPlayCountAt(int index, int value){
    bool successful = false;

    // input validation for value (shouldn't be less than or equal to zero)... return false 
    if(value <= 0){
        return false;
    }

    // if valid input, set play count at index to value and report successful to user... return true
    if(index < SIZE && index >= 0){
        playCount[index] = value;
        successful = true;
    }

    return successful;
};
 
// adds up all the play counts of Listener
int Listener::totalPlayCount(){
    int totalPlayCount = 0;

    for(int i = 0; i < SIZE; i++){
        totalPlayCount += playCount[i];
    }

    return totalPlayCount;
};

// goes through playCount to add up how many songs have 1 or more listens
int Listener::getNumUniqueSongs(){
    int numUniqueSongs = 0;

    for(int i = 0; i < SIZE; i++){
        if(playCount[i] >= 1){
            numUniqueSongs++;
        }
    }

    return numUniqueSongs;
};

// returns SIZE of Listener (should be 50)
int Listener::getSize(){
    return SIZE;
};
