// CSCI 1300 Fall 2021
// Author: Grace Ohlsen
// Recitation: 316 - Teo Price-Broncucia
// Homework 7 - Problem 2

#include "Song.h"

using namespace std;

// Constructor w/ no parameters sets artist, title, and genre to empty strings
Song::Song(){
    title = "";
    artist = "";
    genre = "";
};

// Constructor w/ parameters that sets artist, title, and genre to corresponding input value
Song::Song(string song_title, string song_artist, string song_genre){
    title = song_title;
    artist = song_artist;
    genre = song_genre;
};

// returns string title of Song
string Song::getTitle(){
    return title;
};

// sets title of Song to given value w/ no return value
void Song::setTitle(string song_title){
    title = song_title;
};

// returns string artist of Song
string Song::getArtist(){
    return artist;
};

// sets artist of Song to given value w/ no return value
void Song::setArtist(string song_artist){
    artist = song_artist;
};

// returns string genre of Song
string Song::getGenre(){
    return genre;
};

// sets genre of Song to given value w/ no return value
void Song::setGenre(string song_genre){
    genre = song_genre;
};



