// CSCI 1300 Fall 2021
// Author: Grace Ohlsen
// Recitation: 316 - Teo Price-Broncucia
// Homework 7 - Problem 2

#include <iostream>
#include <iomanip>
#include <fstream>
#include "Song.h"

using namespace std;
/* 
This function takes a string and splits into pieces based on a seperator and stores the pieces in an array of a user-given size
Parameters: string myStr (the string being split), char seperator, string arr[] (where pieces are stored), int arr_size (cannot get size of arr[] without input)
Return: int num_pieces (number of pieces the string was split into)
*/
int split(string myStr, char seperator, string arr[], int arr_size){

    int previous_index = 0;
    int counter = 0;
    int num_pieces = 0;

    

    for(int i = 0; i < myStr.length(); i++){

        if(num_pieces + 1 > arr_size){
            return -1;
        }

        string temp;

        if(i == myStr.length() - 1){

            // if at end of string, take last string (no comma at the end)
            temp = myStr.substr(previous_index, i - previous_index + 1);
            arr[counter] = temp;
            num_pieces++;
            
            

        }else if(myStr[i] == seperator){

            if(previous_index == 0){
                // first substr
                temp = myStr.substr(previous_index, i - previous_index);
                previous_index = i + 1;
                arr[counter] = temp;
                counter++;
                num_pieces++;

            }else{
                // middle substr's sandwiched by commas
                temp = myStr.substr(previous_index , i - previous_index);
                previous_index = i + 1;
                arr[counter] = temp;
                counter++;
                num_pieces++;
            }
            
        }


    }



    return num_pieces;
}

/*
This function reads .txt file of songs and stores Song objects in array with size songArrSize
Parameters: string fileName (name of .txt file), Song arr[] (array of Song objects), int numSongsStored (Song objects already in the array), int songArrSize (size of array)
Return: int counter (total number of Song objects stored in Song arr[])
*/
int readSongs(string fileName, Song arr[], int numSongsStored, int songArrSize){

    // input validation for numSongsStored and songArrSize
    if(numSongsStored < 0 || songArrSize < 0){
        return 0;
    }

    // if numSongsStored = size of song arrary, return -2
    if(numSongsStored == songArrSize){
        return -2;
    }



    ifstream input;
    input.open(fileName);

    if(input.is_open() ){

        input.seekg(0, ios::end);
        unsigned long long last_pos = input.tellg();

        // if the last position is zero, that means the file is empty
        if(last_pos != 0){

            string line;
            int counter = numSongsStored;

            // move cursor back to beginning of file
            input.seekg(0, ios::beg);

            while(getline(input,line) && counter != songArrSize){ // run loop while there are still lines and the array hasn't reached max capacity

                // temporary array for title, artist, and genre
                string temp[3];

                // if line isn't empty, split line and store as Song in array
                if(line != ""){

                    split(line,',', temp,3);

                    arr[counter].setTitle(temp[0]);
                    arr[counter].setArtist(temp[1]);
                    arr[counter].setGenre(temp[2]);

                    counter++;

                }else{
                    // if line is empty, continue to next line
                    continue;
                }


            }

            return counter;

        }else{
            // empty file
            return -1;
        }

        

    }else{
        // unable to open file
        return -1;
    }

    


}

int main(){

    // TEST CASE 1 - Already stored songs
    Song songs[10] = {}; 
    songs[0].setTitle("name1"); 
    songs[0].setArtist("artist1"); 
    songs[0].setGenre("genre1"); 
    readSongs("songs.txt",songs, 1, 10);


    // TEST CASE 2 - Song array already full and .txt file that doesn't exist
    Song songs2[10] = {};
    cout << readSongs("doesnt_exist.txt",songs2, 10, 10) << endl; // expected -2

    // TEST CASE 3 - File doesn't exist
    Song songs3[3] = {};
    cout << readSongs("doesnt_exist.txt", songs3, 1, 3) << endl; // expected -1

    // TEST CASE 4 - No songs previously stored
    Song songs4[50];
    cout << readSongs("songs.txt", songs4, 0, 20) << endl; // expected 20

      for(int i = 0; i < 10; i++){
        Song song = songs[i];
        cout << "Title: " << song.getTitle() << ", Artist: " << song.getArtist() << ", Genre: " << song.getGenre() << endl;
    }





    return 0;
}